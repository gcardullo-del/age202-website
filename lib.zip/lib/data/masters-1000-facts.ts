export type Masters1000FactIcon =
  | "category"
  | "location"
  | "venue"
  | "surface"
  | "founded"
  | "capacity"
  | "climate"
  | "signature";

export type Masters1000Fact = {
  label: string;
  value: string;
  detail: string;
  icon: Masters1000FactIcon;
};

export type Masters1000FactsData = {
  eyebrow: string;
  title: string;
  description: string;
  note?: string;
  facts: Masters1000Fact[];
};

const factsBySlug: Record<string, Masters1000FactsData> = {
  "indian-wells": {
    eyebrow: "Tournament facts",
    title: "The desert masterpiece",
    description:
      "The essential details behind one of the most prestigious and distinctive events on the ATP calendar.",
    note:
      "Indian Wells combines a major-stadium atmosphere with the open landscape and dry climate of the Coachella Valley.",
    facts: [
      {
        label: "Category",
        value: "ATP Masters 1000",
        detail: "One of the highest-level events below the Grand Slams and ATP Finals.",
        icon: "category",
      },
      {
        label: "Location",
        value: "Indian Wells, California",
        detail: "A desert resort city in the Coachella Valley of Southern California.",
        icon: "location",
      },
      {
        label: "Venue",
        value: "Indian Wells Tennis Garden",
        detail: "A purpose-built tennis complex known for its scale, gardens and fan experience.",
        icon: "venue",
      },
      {
        label: "Surface",
        value: "Outdoor hard court",
        detail: "Conditions can reward patience, physical resistance and controlled aggression.",
        icon: "surface",
      },
      {
        label: "Founded",
        value: "1974",
        detail: "The event evolved through several locations before establishing its modern identity.",
        icon: "founded",
      },
      {
        label: "Stadium 1 capacity",
        value: "16,100",
        detail: "One of the largest permanent tennis stadiums in the world.",
        icon: "capacity",
      },
      {
        label: "Climate",
        value: "Dry desert",
        detail: "Warm days, cooler evenings and desert air create a distinctive playing environment.",
        icon: "climate",
      },
      {
        label: "Signature",
        value: "Sunshine Double",
        detail: "Indian Wells and Miami form the celebrated March hard-court double.",
        icon: "signature",
      },
    ],
  },
};

export function getMasters1000Facts(
  slug: string,
): Masters1000FactsData | null {
  return factsBySlug[slug] ?? null;
}
