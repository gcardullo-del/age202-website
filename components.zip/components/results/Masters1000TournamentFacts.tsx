"use client";

import {
  Building2,
  CalendarDays,
  CircleDot,
  CloudSun,
  Crown,
  MapPin,
  Sparkles,
  UsersRound,
  type LucideIcon,
} from "lucide-react";

import type { Masters1000FactIcon } from "@/lib/data/masters-1000-facts";
import { getTournamentFacts } from "@/lib/tournament-engine";

type Masters1000TournamentFactsProps = {
  slug: string;
};

const iconMap: Record<Masters1000FactIcon, LucideIcon> = {
  category: Crown,
  location: MapPin,
  venue: Building2,
  surface: CircleDot,
  founded: CalendarDays,
  capacity: UsersRound,
  climate: CloudSun,
  signature: Sparkles,
};

export default function Masters1000TournamentFacts({
  slug,
}: Masters1000TournamentFactsProps) {
  const data = getTournamentFacts(slug);
  if (!data) return null;

  return (
    <section
      id="facts"
      className="relative scroll-mt-16 overflow-hidden border-t border-white/10 bg-[#030814] px-5 py-20 sm:px-8 lg:px-12 lg:py-28"
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,var(--tournament-glow),transparent_34%)] opacity-35" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.035] [background-image:linear-gradient(rgba(255,255,255,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.08)_1px,transparent_1px)] [background-size:64px_64px]" />

      <div className="relative mx-auto max-w-[1440px]">
        <div className="grid gap-10 xl:grid-cols-[420px_minmax(0,1fr)] xl:items-start">
          <div className="xl:sticky xl:top-28">
            <p className="font-mono text-[9px] font-black uppercase tracking-[0.26em] text-[var(--tournament-primary)]">
              {data.eyebrow}
            </p>
            <h2 className="mt-6 text-5xl font-black uppercase leading-[0.84] tracking-[-0.065em] sm:text-6xl lg:text-7xl">
              {data.title}
            </h2>
            <p className="mt-7 max-w-xl text-sm leading-8 text-white/48 sm:text-base">
              {data.description}
            </p>

            {data.note ? (
              <div className="mt-9 border-l-2 border-[var(--tournament-primary)] pl-5">
                <p className="font-mono text-[8px] font-black uppercase tracking-[0.19em] text-white/28">
                  AGE202 editorial note
                </p>
                <p className="mt-3 text-sm leading-7 text-white/55">{data.note}</p>
              </div>
            ) : null}
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {data.facts.map((fact, index) => {
              const Icon = iconMap[fact.icon];
              const feature = index === 0 || index === 3;

              return (
                <article
                  key={fact.label}
                  className={`group relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#07101D]/92 p-7 transition duration-500 hover:-translate-y-1 hover:border-[var(--tournament-primary)]/60 hover:shadow-[0_30px_90px_rgba(0,0,0,0.35)] sm:p-8 ${
                    feature ? "md:min-h-[390px]" : "md:min-h-[290px]"
                  }`}
                >
                  <div className="pointer-events-none absolute -right-12 -top-16 text-[8rem] font-black leading-none tracking-[-0.08em] text-white/[0.025]">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <div className="pointer-events-none absolute -bottom-20 -right-20 h-56 w-56 rounded-full bg-[var(--tournament-primary)] opacity-0 blur-3xl transition duration-700 group-hover:opacity-10" />

                  <div className="relative flex h-full flex-col">
                    <div className="flex items-start justify-between">
                      <span className="grid h-13 w-13 place-items-center rounded-2xl border border-white/10 bg-white/[0.035] p-3 text-[var(--tournament-primary)]">
                        <Icon size={22} strokeWidth={1.35} aria-hidden="true" />
                      </span>
                      <span className="font-mono text-[8px] font-black tracking-[0.2em] text-white/18">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                    </div>

                    <p className="mt-10 font-mono text-[8px] font-black uppercase tracking-[0.2em] text-white/30">
                      {fact.label}
                    </p>
                    <h3 className={`mt-4 font-black uppercase leading-[0.9] tracking-[-0.055em] ${feature ? "text-4xl sm:text-5xl" : "text-3xl"}`}>
                      {fact.value}
                    </h3>
                    <p className="mt-auto pt-8 text-sm leading-7 text-white/40">
                      {fact.detail}
                    </p>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
